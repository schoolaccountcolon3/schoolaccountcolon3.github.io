<?php
$domain_url = \helper\options::options_by_key_type('base_url');
$site_name = \helper\options::options_by_key_type('site_name');
$theme_url = '/' . DIR_THEME;
$game = \helper\game::find_by_slug($slug);
if ($game != null) {
    \helper\game::update_views($game->id);
}
if ($game->source_html != '') {
    if (strpos($game->source_html, 'gamedistribution') || strpos('gamedistribution', $game->source_html)) {
        $game->source_html = $game->source_html . '?gd_sdk_referrer_url=' . $domain_url . '/' . $game->slug . '.embed';
    }
}
$banner = $domain_url . \helper\image::get_thumbnail($game->image, 200, 200, 'm');
$headers = apache_request_headers();

?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Play <?php echo $game->name ?> game!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimal-ui, shrink-to-fit=no viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="<?php echo $site_name; ?>">
    <meta name="HandheldFriendly" content="true" />
    <meta name="mobile-web-app-capable" content="yes" />
    <link rel="shortcut icon" sizes="512x512" href="<?php echo $domain_url . \helper\image::get_thumbnail(\helper\options::options_by_key_type('favicon'), 512, 512); ?>" />
    <link rel="icon" type="image/x-icon" href="<?php echo $domain_url; ?>/favicon.ico?v=1">
    <link rel="apple-touch-icon" href="<?php echo $domain_url . \helper\image::get_thumbnail(\helper\options::options_by_key_type('favicon'), 512, 512); ?>">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="canonical" href="<?php echo $domain_url . '/' . $game->slug; ?>" data-react-helmet="true">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <style>
        html,
        body,
        #theGameBox {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 0;
            margin: 0;
        }
    </style>

    <style>
        .gamePlayerContentSafeSize {
            width: 1598px;
            height: 841px;
            max-width: 100%;
            position: relative;
            ;
        }

        @-webkit-keyframes gamePlayerMoveRight {
            to {
                -webkit-transform: translateX(20px)
            }
        }

        @keyframes gamePlayerMoveRight {
            to {
                transform: translateX(20px)
            }
        }

        @-webkit-keyframes gamePlayerMoveLeft {
            to {
                -webkit-transform: translateX(-20px)
            }
        }

        @keyframes gamePlayerMoveLeft {
            to {
                transform: translateX(-20px)
            }
        }

        .gamePlayerPageLoader svg {
            z-index: -1
        }

        .gamePlayerLoadingAnim {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 100000000;
            background: rgba(0, 0, 0, .70);
        }

        .gamePlayerLoadingAnim div {
            box-sizing: border-box;
            display: block;
            position: absolute;
            width: 64px;
            height: 64px;
            margin: 4px;
            animation: gamePlayerLoadingAnim 1s infinite;
            border-style: solid;
            border-color: #fff transparent transparent transparent;
            border-width: 3px;
            border-radius: 50%;
        }

        .gamePlayerLoadingAnim div:nth-child(1) {
            animation-delay: -0.9s;
        }

        .gamePlayerLoadingAnim div:nth-child(2) {
            animation-delay: -0.8s;
        }

        .gamePlayerLoadingAnim div:nth-child(3) {
            animation-delay: -0.1s;
        }

        @keyframes gamePlayerLoadingAnim {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .gamePlayerLoadingAnim span {
            font-family: 'roboto', sans-serif;
            width: 100%;
            text-align: center;
            color: #fff;
            padding-top: 150px;
            position: absolute;
            z-index: 99999999999999999999;
        }

        .gamePlayerTable>div {
            display: table-cell;
            vertical-align: middle;
            padding: 10px;
            text-align: left;
            width: auto;
            background: #fff;
            color: #272727;
        }

        .gamePlayerTable>div:first-child {
            width: 1%;
            white-space: nowrap;
            font-size: 22px;
            font-weight: 600;
            vertical-align: top
        }

        [data-gamePlayerplayer] div video {
            width: 100% !important;
            height: 100% !important;
        }

        [data-gamePlayerplayer] div lima-video {
            width: 100% !important;
            height: 100% !important;
        }

        .gamePlayerContent video {
            left: 0;
            top: 0;
        }

        .gamePlayerContent {
            top: 0;
            left: 0;
        }

        .gamePlayerHidden {
            display: none !important;
            visibility: hidden;
        }

        .gamePlayerCenterTable>div {
            display: table-cell;
            text-align: left;
            vertical-align: middle;
            font-size: 22px;
        }

        .gamePlayerCenterTable>div:nth-child(2) {
            padding: 10px 30px;
            text-align: center;
            display: inline-block;
        }

        #gamePlayermw1jclueedb9wbbpdztq {
            width: 100%;
        }

        #gamePlayermw1jclueedb9wbbpdztq {
            background-color: #000;
            overflow: hidden;
        }

        #gamePlayermw1jclueedb9wbbpdztq {
            padding: inherit;
            box-sizing: border-box;
            overflow: hidden;
            position: relative;
            z-index: 9999;
        }

        body>#gamePlayermw1jclueedb9wbbpdztq {
            position: fixed !important;
        }

        #gamePlayermw1jclueedb9wbbpdztq.gamePlayerMidroll {
            background: rgba(0, 0, 0, 1);
        }

        #gamePlayermw1jclueedb9wbbpdztq>div:first-child {
            z-index: 2147483647;
        }

        #gamePlayermw1jclueedb9wbbpdztq.gamePlayerNoClick>div:first-child {
            z-index: 2147483646;
        }

        #gamePlayermw1jclueedb9wbbpdztq:not(.gamePlayerAdLoaded)>div:not([class]) {
            pointer-events: none;
        }

        .gamePlayerContent {
            position: relative;
        }

        #gamePlayermw1jclueedb9wbbpdztq .gamePlayerLoadingContainer>div {
            display: none;
        }

        #gamePlayermw1jclueedb9wbbpdztq .gamePlayerLoadingContainer>div {
            width: 25px;
            height: 25px;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-left: -15px;
            margin-top: -15px;
            animation: circle 0.75s linear infinite;
            border-width: 2px;
            border-style: solid;
            border-color: rgba(252, 12, 12, 0) rgb(255, 255, 255) rgba(201, 62, 201, 0) rgb(255, 255, 255);
            border-image: initial;
            border-radius: 100%;
            -webkit-animation: spin 1s linear infinite;
            animation: spin 1s linear infinite;
            transform-origin: center !important;
        }

        @-webkit-keyframes spin {
            0% {
                -webkit-transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(360deg);
            }
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes gamePlayerTicTac {
            0% {
                transform: scale(1, 1);
            }

            50% {
                transform: scale(1.2, 1.2);
            }

            100% {
                transform: scale(1, 1);
            }
        }

        .gamePlayerInstallFlash>div {
            display: table-cell;
            text-align: center;
            vertical-align: middle;
            width: 100%;
            height: 100%;
            color: #fff;
            font-family: "open sans";
            font-size: 18px;
            letter-spacing: -1px;
        }

        .gamePlayerInstallFlash>div>a {
            display: block;
            text-align: center;
            color: yellow;
            padding: 10px;
        }

        .gamePlayerContextMenu li {
            border-bottom: 1px solid rgba(255, 255, 255, .8);
            padding: 5px;
            color: rgba(255, 555, 255, .6);
            list-style-type: none;
            padding: 10px 0;
            font-family: roboto;
            font-size: 11px;
            text-align: left;
        }

        .gamePlayerContextMenu li a {
            color: rgba(255, 555, 255, .6);
            font-family: roboto;
            font-size: 11px;
            text-align: left;
            text-decoration: none;
        }

        .gamePlayerContextMenu li a:hover {
            text-decoration: underline
        }

        .gamePlayerContextMenu li:last-child {
            border-bottom: none;
        }

        .gamePlayerContextMenu li span {
            cursor: pointer;
            font-size: 12px;
            display: block;
            text-align: left;
            font-weight: normal;
            font-family: 'roboto'
        }

        #gamePlayermw1jclueedb9wbbpdztq iframe:first-of-type {
            display: block !important;
            background: none !important;
            border: none !important;
        }

        #gamePlayermw1jclueedb9wbbpdztq .gamePlayerFlashSplash embed {
            transform: scale(100);
        }

        .loadingButton span {
            opacity: 0;
            transition: .2s;
        }

        @keyframes bounceHorizontal {
            0% {
                left: -4px;
            }

            100% {
                left: 4px;
            }
        }

        @keyframes openChest {
            from {
                background-position-x: 0px;
            }

            to {
                background-position-x: -294px;
            }
        }

        @keyframes popIn {
            0% {
                -webkit-transform: scale(0);
                transform: scale(0);
                opacity: 1;
            }

            70% {
                -webkit-transform: scale(1.2);
                transform: scale(1.2);
                opacity: 1;
            }

            100% {
                -webkit-transform: scale(1);
                transform: scale(1);
                opacity: 1;
            }
        }

        :root {
            --min5050: 50px;
            --min202: 20px;
            --min203: 20px;
            --min405: 40px;
            --min255: 25px;
            --min143: 14px;
            --min22040: 150px;
            --min15015: 150px;
            --min505: 50px;
            --min364: 36px;
            --min202: 20px;
        }

        @supports (padding:min(12px, 13vw)) {
            :root {
                --min5050: min(50px, 5vw);
                --min202: min(20px, 2vw);
                --min405: 40px;
                --min203: min(20px, 3vh);
                --min405: min(40px, 5vw);
                --min255: min(25px, 5vw);
                --min143: min(14px, 3vw);
                --min22040: min(220px, 40vw);
                --min15015: min(150px, 15vw);
                --min505: min(50px, 5vw);
                --min364: min(36px, 4vh);
                --min202: min(20px, 2vw);
            }
        }

        @import url(https://fonts.googleapis.com/css2?family=Roboto:gamePlayerht@100;300;400;500&display=swap);

        .gamePlayerSplash * {
            box-sizing: border-box;
            font-family: Roboto, sans-serif !important;
            font-weight: 300;
        }

        .gamePlayerSplash {
            display: block;
            padding: var(--min5050);
            overflow: hidden;
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            position: relative;
            background-color: #000;
            outline: none !important;
            transition: opacity .4s;
            background-repeat: no-repeat;
            background-position: center;
        }

        .gamePlayerSplash .gamePlayerBg {
            display: block;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1
        }

        .gamePlayerSplash .gamePlayerBg .gamePlayerBgImage {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            filter: blur(45px);
            background-size: cover;
            transform: scale(1.3)
        }

        .gamePlayerSplash .gamePlayerSplashContent {
            background: rgba(255, 255, 255, .4);
            border-radius: 50px;
            display: block;
            width: 100%;
            height: 100%;
            z-index: 10;
            box-shadow: 0px 0px 0px 0px #ffffff, 10px 20px 21px rgba(0, 0, 0, .4);
            position: relative;
            transition: box-shadow .2s;
        }

        .gamePlayerSplash .gamePlayerSplashContent:hover {
            box-shadow: -2px -2px 10px 1px #ffffff, 10px 20px 21px rgba(0, 0, 0, .4);
        }

        .gamePlayerSplashContent .gamePlayerCenterContent {
            display: grid;
            width: 100%;
            height: 100%;
            grid-template-columns: 2fr 1fr;
            box-sizing: border-box;
            place-items: center;
            padding: var(--min202);
        }

        .gamePlayerSplashContent .gamePlayerCenterContent>div {
            text-align: center;
            padding: var(--min202);
            width: 100%
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollInfo {
            display: grid;
            width: 100%;
            text-align: left;
            row-gap: 20px
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerButtons {
            display: inline-block;
            text-align: center;
            display: grid;
            row-gap: 20px;
            width: max-content;
            padding: 20px
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollCTA {
            transition: .2s;
            position: relative;
            cursor: pointer;
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollCTA:hover {
            transform: scale(1.1)
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollCTA span {
            display: grid;
            grid-template-columns: auto auto;
            grid-gap: 10px;
            background-color: #1c1c1c;
            color: #fff;
            border-radius: 100px;
            padding: var(--min203) var(--min405);
            font-weight: 400;
            font-size: var(--min255);
            box-shadow: 0 0 20px rgba(0, 0, 0, .8);
            align-items: center;
            cursor: pointer;
            transition: .3s;
            text-transform: uppercase;
            user-select: none;
            pointer-events: none;
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollCTA:hover span {
            background-color: #91000a
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollCTA span:before {
            display: block;
            content: " ";
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAPCAYAAADUFP50AAABKklEQVQokY2TvyvEcRjHX75dDFIGFhmuFFaLC7NFERkNBvInuCubhdtsBsUimVx28iPJarHSme4kAyU/6qVPPur6du7uqc+zPJ/3834/7+fzQR1Un9RzNavSykmAXaAMVIB7YAvopVmoFXU9skypD+qbuqZm/mMPqaxupAp59V2tqrNqkgYmUVBbSlgR6Ab2gBJwBeRqLyQNJvkA8kBPnP8GOAGyzYB/8QzMARNAF3AGTLcC7I+s11HuKXDQCBi6bwMXcd5O4BCYAVbrAYNRi8Aj0AesAMvAKzAcZIaGmTrAfWASWIim7ESp89Hh34h73KzZ0ai6pJbUF7gamePlayerdqT3GBjbga/YZwQoAGPAETAEVOs6oN6ql2pR/VaP1YFmDz2kcfVTvVNzLf0O5QcZKy4YNKUs+wAAAABJRU5ErkJggg==);
            background-repeat: no-repeat;
            background-position: center;
            width: 15px;
            height: 15px
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollCTA:hover span:before {
            animation: gamePlayerKnock .3s infinite
        }

        @keyframes gamePlayerKnock {
            0% {
                transform: translateX(0)
            }

            100% {
                transform: translateX(-10px)
            }
        }

        .gamePlayerSplashContent .gamePlayerCenterContent .gamePlayerPrerollWb span {
            display: inline-block;
            border: 2px solid #1c1c1c;
            color: #1c1c1c;
            border-radius: 100px;
            padding: 15px 20px;
            text-transform: uppercase;
            font-weight: 500;
            font-size: var(--min143);
            box-shadow: 0 0 20px rgba(0, 0, 0, .8);
            cursor: pointer;
            user-select: none;
        }

        .gamePlayerThumb {
            display: block;
            position: relative;
            border-radius: 50%;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, .4);
            width: var(--min22040);
            height: var(--min22040);
            transition: .3s;
            cursor: pointer;
            margin: auto;
        }

        .gamePlayerThumb:hover {
            transform: scale(1.1);
            box-shadow: -2px -2px 10px 1px #ffffff, 0 5px 40px rgba(0, 0, 0, .4)
        }

        .gamePlayerThumb>div {
            position: absolute;
            border-radius: 50%;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        .gamePlayerTitle {
            font-weight: 300;
            font-size: var(--min364);
            user-select: none;
            color: #1c1c1c;
            line-height: normal;
        }

        .gamePlayerTitle:after {
            content: "" !important;
        }

        .gamePlayerPrerollDescription {
            font-weight: 400;
            font-size: 15px;
            user-select: none;
            color: #1c1c1c;
        }

        .gamePlayerSplash {
            opacity: 0;
        }

        .gamePlayerPrerollCTA {
            position: relative;
        }

        .gamePlayerSplash {
            opacity: 1;
        }

        .gamePlayerBg .gamePlayerBgImage {
            background-image: url('<?php echo $banner; ?>') !important;
        }

        .gamePlayerThumb>div {
            background-image: url(<?php echo $banner; ?>);
        }

        @media only screen and (max-width: 480px) {
            .gamePlayerThumb {
                display: none
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500&amp;display=swap">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <?php include 'ads/adbreak.php'; ?>
    <script>
        function showAFG() {
            var show_ads = (typeof adBreak !== 'undefined') ? true : false;

            var domain = '<?php echo $headers['Host']; ?>';
            if (window != window.top && document.referrer != null) {
                url = document.referrer;
                ref = url.match(/:\/\/(.[^/]+)/)[1];
                if (ref != domain) {
                    show_ads = false;
                }

            }

            if (show_ads) {
                console.log("show ads");
                // Game start logic
                let adConfigPromise =
                    new Promise((resolve, reject) => adConfig({
                        preloadAdBreaks: 'on',
                        onReady: () => resolve(true)
                    }));
                let timeoutPromise =
                    new Promise((resolve, reject) => {
                        setTimeout(() => {
                            resolve(false);
                        }, 2000);
                    });
                // Whatever happens first resolves this promise.
                Promise.race([
                    adConfigPromise,
                    timeoutPromise
                ]).then((shouldShowPreRoll) => {
                    if (shouldShowPreRoll) {
                        showPreRoll();
                    } else {
                        showGamePlayerFrame();
                    }
                });
            } else {
                console.log("no show ads");
                showGamePlayerFrame();
            }

        }

        function showPreRoll() {
            // Show ad
            adBreak({
                type: 'preroll',
                adBreakDone: showGamePlayerFrame, // always called, unblocks the game logic

            });
        }

        function showGamePlayerFrame() {
            $(".gamePlayerSplash").addClass('gamePlayerHidden');
            $(".gamePlayerLoadingAnim").removeClass('gamePlayerHidden');
            setTimeout(function() {
                $(".gamePlayerLoadingAnim").addClass('gamePlayerHidden');
                $("#gameFrame").removeClass('gamePlayerHidden');
            }, 2000);
        }
    </script>
</head>

<body cz-shortcut-listen="true" aria-hidden="false">

    <div id="theGameBox" class="gamePlayerContentSafeSize gamePlayerContent">
        <div id="gamePlayermw1jclueedb9wbbpdztq" data-gamePlayerplayer="true" class="">
            <div class="gamePlayerSplashPreroll gamePlayerSplash">
                <div class="gamePlayerBg">
                    <div class="gamePlayerBgImage"></div>
                </div>
                <div class="gamePlayerSplashContent">
                    <div class="gamePlayerCenterContent">
                        <div>
                            <div class="gamePlayerPrerollInfo">
                                <div class="gamePlayerButtons">
                                    <div class="gamePlayerPrerollCTA" id="btn_playgame" onclick="showAFG()">
                                        <span>Play game</span>
                                    </div>
                                </div>
                                <?php if (strpos(strtolower($game->name), "sprunki") === 0 || strpos(strtolower($game->name), "sprunki")) : ?>
                                    <div style="margin-top: -21px; padding-left: 21px;">WARNING: This game contains disturbing images and scenes of explicit violence and gore.</div>
                                <?php endif ?>
                                <div class="gamePlayerTitle"><?php echo $game->name; ?></div>
                                <div class="gamePlayerPrerollDescription"><?php echo $game->excerpt; ?>
                                </div>

                            </div>
                        </div>
                        <div>
                            <div class="gamePlayerThumb">
                                <div></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


        </div>
        <iframe title="Game Frame" class="gamePlayerHidden" src="<?php echo $game->source_html; ?>" id="gameFrame" width="100%" height="100%"
            frameborder="0"
            data-gamePlayer-content="true"></iframe>
        <div class="gamePlayerLoadingAnim gamePlayerHidden">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <span>Game will resume momentarily...</span>
        </div>
    </div>
</body>

</html>